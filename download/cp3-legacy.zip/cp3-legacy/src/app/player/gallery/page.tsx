import type { Metadata } from "next";
import React, { useState } from "react";
import { MobileHeader } from "@/components/alchemists/MobileHeader";
import { Header } from "@/components/alchemists/Header";
import { Footer } from "@/components/alchemists/Footer";
import data from "@/data/player/gallery.json";

export const metadata: Metadata = {
  title: "Player Gallery — Chris Paul",
  description: "Photo gallery of Chris Paul — game action, portraits, off-court moments.",
};

export default function PlayerGalleryPage() {
  const { player, categories, photos } = data;
  const [activeCategory, setActiveCategory] = useState("all");

  const filteredPhotos = activeCategory === "all"
    ? photos
    : photos.filter((p) => p.category === activeCategory);

  return (
    <div className="site-wrapper clearfix">
      <MobileHeader />
      <Header onTogglePushyPanel={() => {}} />

      <div className="player-heading">
        <div className="container">
          <div className="player-info">
            <div className="player-info__title">
              <div className="player-info__number">{player.number}</div>
              <h1 className="player-info__name">
                {player.firstName} <span className="player-info__last-name">{player.lastName}</span>
              </h1>
              <div className="player-info__nickname">{player.nickname} — Gallery</div>
            </div>
          </div>
        </div>
      </div>

      <div className="site-content">
        <div className="container">

          {/* Category Filter */}
          <nav className="content-filter">
            <ul className="content-filter__list">
              {categories.map((cat) => (
                <li
                  key={cat.id}
                  className={`content-filter__item ${activeCategory === cat.id ? "active" : ""}`}
                >
                  <button
                    onClick={() => setActiveCategory(cat.id)}
                    className="content-filter__link"
                  >
                    {cat.name} <span className="highlight">({cat.count})</span>
                  </button>
                </li>
              ))}
            </ul>
          </nav>

          {/* Photo Grid */}
          <section className="player-gallery">
            <div className="gallery-grid gallery-grid--4cols">
              {filteredPhotos.map((photo) => (
                <div key={photo.id} className="gallery-grid__item">
                  <a href={photo.url} className="gallery-item" target="_blank" rel="noopener noreferrer">
                    <img
                      src={photo.thumbnail}
                      alt={photo.title}
                      className="gallery-item__img"
                      loading="lazy"
                    />
                    <div className="gallery-item__info">
                      <h4 className="gallery-item__title">{photo.title}</h4>
                      <div className="gallery-item__date">{photo.date}</div>
                      <p className="gallery-item__caption">{photo.caption}</p>
                    </div>
                  </a>
                </div>
              ))}
            </div>

            {filteredPhotos.length === 0 && (
              <div className="gallery-empty">
                <p>No photos in this category yet.</p>
              </div>
            )}
          </section>

        </div>
      </div>

      <Footer />
    </div>
  );
}
