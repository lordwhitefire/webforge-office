import type { Metadata } from "next";
import React from "react";
import { MobileHeader } from "@/components/alchemists/MobileHeader";
import { Header } from "@/components/alchemists/Header";
import { Footer } from "@/components/alchemists/Footer";
import data from "@/data/player/overview.json";

export const metadata: Metadata = {
  title: "Player Overview — Chris Paul",
  description: "Career overview of Chris Paul — the Point God. 20 seasons, 12 All-Star selections, NBA 75th Anniversary Team.",
};

export default function PlayerOverviewPage() {
  const { player, info, careerAverages, currentTeam, lastGames, relatedNews } = data;

  return (
    <div className="site-wrapper clearfix">
      <MobileHeader />
      <Header onTogglePushyPanel={() => {}} />

      <div className="player-heading">
        <div className="container">
          <div className="player-info">
            <div className="player-info__team-logo">
              <img src={player.headshot} alt={`${player.firstName} ${player.lastName}`} />
            </div>
            <div className="player-info__title">
              <div className="player-info__number">{player.number}</div>
              <h1 className="player-info__name">
                {player.firstName} <span className="player-info__last-name">{player.lastName}</span>
              </h1>
              <div className="player-info__nickname">{player.nickname} — "{player.nicknameLong}"</div>
              <div className="player-info__team">{currentTeam.name}</div>
            </div>
          </div>

          <div className="player-info__stats">
            <div className="player-info__stat">
              <span className="player-info__stat-label">Height</span>
              <span className="player-info__stat-value">{info.height}</span>
            </div>
            <div className="player-info__stat">
              <span className="player-info__stat-label">Weight</span>
              <span className="player-info__stat-value">{info.weight}</span>
            </div>
            <div className="player-info__stat">
              <span className="player-info__stat-label">Age</span>
              <span className="player-info__stat-value">{info.age}</span>
            </div>
            <div className="player-info__stat">
              <span className="player-info__stat-label">College</span>
              <span className="player-info__stat-value">{info.college}</span>
            </div>
            <div className="player-info__stat">
              <span className="player-info__stat-label">Born</span>
              <span className="player-info__stat-value">{info.born}</span>
            </div>
            <div className="player-info__stat">
              <span className="player-info__stat-label">Position</span>
              <span className="player-info__stat-value">{info.position}</span>
            </div>
          </div>
        </div>
      </div>

      <div className="site-content">
        <div className="container">
          <section className="player-info__career-avg">
            <h2 className="player-info__section-title">Career Averages</h2>
            <div className="row">
              <div className="col-md-4">
                <div className="circular-bar circular-bar--center">
                  <div className="circular-bar__value">{careerAverages.pointsPerGame}</div>
                  <div className="circular-bar__label">Points per game</div>
                </div>
              </div>
              <div className="col-md-4">
                <div className="circular-bar circular-bar--center">
                  <div className="circular-bar__value">{careerAverages.assistsPerGame}</div>
                  <div className="circular-bar__label">Assists per game</div>
                </div>
              </div>
              <div className="col-md-4">
                <div className="circular-bar circular-bar--center">
                  <div className="circular-bar__value">{careerAverages.reboundsPerGame}</div>
                  <div className="circular-bar__label">Rebounds per game</div>
                </div>
              </div>
            </div>
          </section>

          <section className="player-last-games">
            <h2 className="player-info__section-title">Last Games Log</h2>
            <div className="table-responsive">
              <table className="table table--lg team-roster__table">
                <thead>
                  <tr>
                    <th>Opponent</th>
                    <th>Date</th>
                    <th>Result</th>
                    <th>PTS</th>
                    <th>AST</th>
                    <th>REB</th>
                  </tr>
                </thead>
                <tbody>
                  {lastGames.map((g, i) => (
                    <tr key={i}>
                      <td>{g.opponent}</td>
                      <td>{g.date}</td>
                      <td>{g.result}</td>
                      <td>{g.points}</td>
                      <td>{g.assists}</td>
                      <td>{g.rebounds}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>

          <section className="player-related-news">
            <h2 className="player-info__section-title">Player Related News</h2>
            <div className="posts posts--cards post-grid post-grid--2cols post-grid--fit">
              {relatedNews.map((post, i) => (
                <div key={i} className="post-grid__item col-6">
                  <div className="posts__item posts__item--card card">
                    <div className="posts__inner card__content">
                      <div className="posts__cat">{post.category}</div>
                      <h2 className="posts__title">
                        <a href={`/news/${post.slug}`}>{post.title}</a>
                      </h2>
                      <div className="posts__excerpt">{post.excerpt}</div>
                      <div className="posts__date">{post.date}</div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </section>
        </div>
      </div>

      <Footer />
    </div>
  );
}
