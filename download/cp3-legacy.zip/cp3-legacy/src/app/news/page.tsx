import type { Metadata } from "next";
import React from "react";
import { MobileHeader } from "@/components/alchemists/MobileHeader";
import { Header } from "@/components/alchemists/Header";
import { Footer } from "@/components/alchemists/Footer";
import data from "@/data/news/listing.json";

export const metadata: Metadata = {
  title: "Latest News — CP3 Legacy",
  description: "Coverage of Chris Paul's 20th NBA season, milestones, and legacy.",
};

export default function NewsPage() {
  const { page, categories, featuredPost, posts } = data;

  return (
    <div className="site-wrapper clearfix">
      <MobileHeader />
      <Header onTogglePushyPanel={() => {}} />

      <div className="site-content">
        <div className="container">

          {/* Page Header */}
          <header className="page-header">
            <h1 className="page-header__title">{page.title}</h1>
            <p className="page-header__subtitle">{page.subtitle}</p>
          </header>

          {/* Featured Post */}
          <section className="featured-post">
            <div className="card card--lg">
              <div className="card__content">
                <div className="posts__cat">{featuredPost.categoryLabel}</div>
                <h2 className="posts__title posts__title--lg">
                  <a href={`/news/${featuredPost.slug}`}>{featuredPost.title}</a>
                </h2>
                <div className="posts__excerpt">{featuredPost.excerpt}</div>
                <div className="posts__meta">
                  <span className="posts__date">{featuredPost.date}</span>
                  <span className="posts__author">by {featuredPost.author}</span>
                </div>
              </div>
            </div>
          </section>

          {/* Category Filter (visual only) */}
          <nav className="content-filter">
            <ul className="content-filter__list">
              {categories.map((cat) => (
                <li key={cat.id} className={`content-filter__item ${cat.id === "all" ? "active" : ""}`}>
                  <span className="content-filter__link">
                    {cat.name} <span className="highlight">({cat.count})</span>
                  </span>
                </li>
              ))}
            </ul>
          </nav>

          {/* Posts Grid */}
          <section className="posts posts--cards post-grid post-grid--2cols post-grid--fit">
            {posts.map((post, i) => (
              <div key={i} className="post-grid__item col-6">
                <article className="posts__item posts__item--card card">
                  <div className="posts__inner card__content">
                    <div className="posts__cat">{post.categoryLabel}</div>
                    <h2 className="posts__title">
                      <a href={`/news/${post.slug}`}>{post.title}</a>
                    </h2>
                    <div className="posts__excerpt">{post.excerpt}</div>
                    <div className="posts__meta">
                      <span className="posts__date">{post.date}</span>
                      <span className="posts__read-time">{post.readTime}</span>
                    </div>
                  </div>
                </article>
              </div>
            ))}
          </section>

        </div>
      </div>

      <Footer />
    </div>
  );
}
