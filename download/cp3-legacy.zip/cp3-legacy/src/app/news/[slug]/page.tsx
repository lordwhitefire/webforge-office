import type { Metadata } from "next";
import React from "react";
import { notFound } from "next/navigation";
import Link from "next/link";
import { MobileHeader } from "@/components/alchemists/MobileHeader";
import { Header } from "@/components/alchemists/Header";
import { Footer } from "@/components/alchemists/Footer";
import fs from "fs";
import path from "path";

type PostBody =
  | { type: "paragraph"; text: string }
  | { type: "heading"; level: number; text: string };

interface PostData {
  slug: string;
  title: string;
  category: string;
  categoryLabel: string;
  date: string;
  author: string;
  image: string;
  readTime: string;
  excerpt: string;
  tags: string[];
  body: PostBody[];
}

function loadPost(slug: string): PostData | null {
  const postsDir = path.join(process.cwd(), "src", "data", "news", "posts");
  const filePath = path.join(postsDir, `${slug}.json`);
  if (!fs.existsSync(filePath)) return null;
  return JSON.parse(fs.readFileSync(filePath, "utf-8"));
}

export function generateStaticParams() {
  const postsDir = path.join(process.cwd(), "src", "data", "news", "posts");
  if (!fs.existsSync(postsDir)) return [];
  return fs.readdirSync(postsDir)
    .filter((f) => f.endsWith(".json"))
    .map((f) => ({ slug: f.replace(".json", "") }));
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const post = loadPost(slug);
  if (!post) return { title: "Post Not Found" };
  return {
    title: `${post.title} — CP3 Legacy`,
    description: post.excerpt,
    openGraph: {
      title: post.title,
      description: post.excerpt,
      type: "article",
      publishedTime: post.date,
      authors: [post.author],
    },
  };
}

export default async function BlogPostPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const post = loadPost(slug);
  if (!post) notFound();

  return (
    <div className="site-wrapper clearfix">
      <MobileHeader />
      <Header onTogglePushyPanel={() => {}} />

      <div className="site-content">
        <div className="container">
          <div className="row">
            <div className="content col-lg-8">

              <article className="card card--lg card--block post post--single">
                <div className="card__content">

                  {/* Post Header */}
                  <header className="post__header">
                    <div className="post__category">
                      <Link href="/news">{post.categoryLabel}</Link>
                    </div>
                    <h1 className="post__title">{post.title}</h1>
                    <div className="post__meta">
                      <span className="post__date">{post.date}</span>
                      <span className="post__author">by {post.author}</span>
                      <span className="post__read-time">{post.readTime}</span>
                    </div>
                  </header>

                  {/* Featured Image */}
                  {post.image && (
                    <figure className="post__thumbnail">
                      <img src={post.image} alt={post.title} />
                    </figure>
                  )}

                  {/* Excerpt */}
                  <div className="post__excerpt">
                    <strong>{post.excerpt}</strong>
                  </div>

                  {/* Body */}
                  <div className="post__content">
                    {post.body.map((block, i) => {
                      if (block.type === "paragraph") {
                        return <p key={i} className="post__paragraph">{block.text}</p>;
                      }
                      if (block.type === "heading") {
                        const Tag = `h${block.level}` as keyof JSX.IntrinsicElements;
                        return <Tag key={i} className="post__heading">{block.text}</Tag>;
                      }
                      return null;
                    })}
                  </div>

                  {/* Tags */}
                  {post.tags.length > 0 && (
                    <div className="post__tags">
                      {post.tags.map((tag, i) => (
                        <span key={i} className="post__tag">#{tag}</span>
                      ))}
                    </div>
                  )}

                  {/* Back to News */}
                  <div className="post__footer">
                    <Link href="/news" className="btn btn-primary btn-sm">
                      ← Back to News
                    </Link>
                  </div>

                </div>
              </article>

            </div>

            {/* Sidebar */}
            <aside className="sidebar col-lg-4">
              <div className="card card--block">
                <div className="card__content">
                  <h4 className="sidebar__title">About CP3 Legacy</h4>
                  <p className="sidebar__text">
                    CP3 Legacy is a fan site dedicated to the career of Chris Paul — 20 seasons, 12 All-Star selections, NBA 75th Anniversary Team.
                  </p>
                  <a href="/player/overview" className="btn btn-inverse btn-sm btn-outline">
                    View Player Overview
                  </a>
                </div>
              </div>
            </aside>

          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}
